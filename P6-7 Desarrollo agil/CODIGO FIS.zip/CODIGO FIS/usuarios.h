#pragma once

#include <iostream>
#include <cstring>
#include <fstream>


using namespace std;

class Usuario
{
private:
	string nombre_;                     // Este atributo se encarga de almacenar el nombre del usuario
	string contrasena_;                 // Este atributo se encarga de almacenar la contrase�a del usuario
	bool privilegio_;                   // Este atributo es para poder diferenciar a un alumno de un profesor profesor=true alumno=false

public:

	Usuario() {
		nombre_ = "";
		contrasena_ = "";
		privilegio_ = false;
	}

	Usuario(string nombre, bool privilegio, string contrasena)
	{
		nombre_ = nombre;
		contrasena_ = contrasena;
		privilegio_ = privilegio;
	}

	void crear_usuario(void)
	{
		cout << "Por favor, introduzca un su nombre :" << "\n";
		do
		{
			cin >> nombre_;
			if (nombre_ == "")
			{
				cout << "Por favor, introduzca un nombre" << "\n";
			}
		} while (nombre_ == "");

		cout << "Ahora introduzca la contraseña que desea emplear, debe ser como minimo de 6 caracteres" << "\n";
		do
		{
			cin >> contrasena_;
			if (contrasena_.size() < 6)
				cout << "Por favor, introduzca una contraseña valida" << "\n";
		} while (contrasena_.size() < 6);

		cout << "¿Es usted \"profesor\" o \"alumno\"?" << "\n";
		string ser;
			do
			{
				cin >> ser;
				if (ser == "profesor")
				{
                 privilegio_=true;
				}
				else if (ser =="alumno")
				{
				    privilegio_=false;
				}
				else{
				cout << "Por favor, indique correctamente qué tipo de usuario es" << "\n";	
				}
			} while (ser != "profesor" && ser != "alumno");

		ifstream fich1 ;
		//ofstream fich2;

		fich1.open("passwd.txt", ios::in);
	//	fich2.open("passwd.txt", ios::out);

		if (fich1.fail()) {
			cout << "No se pudo leer del fichero de datos\n";
		}
		else {

			bool encontrado_ = false;
			bool pass_corr_ = false;
			string usu;
			string pass;

			while (!fich1.eof() && ((pass_corr_ && encontrado_) != true)) {

				getline(fich1, usu, '\n');
				getline(fich1, pass, '\n');

				if (nombre_ == usu) {

					if (contrasena_ == pass) {
						pass_corr_ = true;
					}
					else {
						pass_corr_ = false;
					}
					encontrado_ = true;
				}
				else {
					encontrado_ = false;
				}

			}

			if ((encontrado_ == true) && (pass_corr_ == true)) {
				cout << "Usuario ya existente" << endl;
			}
			
			else if ((encontrado_)&&(pass_corr_ == false))
			{
				cout << "Usuario ya registrado con otra contraseña\n";
			}
			else {
				//fich2 << nombre_ << endl;
				//fich2 << contrasena_ << endl;
				escribir_fichero(nombre_, contrasena_, ser);
			}

			fich1.close();
		//	fich2.close();


		}
				cout << "\nEl registro ha sido completado con EXITO \n\n";

	}
	
	void escribir_fichero(string usu, string pass, string ser){
				

				ofstream fich2;
				fich2.open("passwd.txt", ios::app);

			
					fich2 << usu << endl;
					fich2 << pass << endl;
					fich2 << ser << endl;
				


	}

	void mostrar_datos(void)
	{
     cout << "El nombre del usuario es: " << nombre_ << "\n\n";
	 cout << "Su contraseña es: " << contrasena_ << endl;

	/* int contador=0;
	 while (contador != contrasena_.size()){

		 cout << "*";
		 contador++;
	 }*/
	 cout << "\n\n";
	 cout << "Su nivel de privilegio es de: ";
	 if (privilegio_==true )
	 {
      cout << "Profesor" << "\n\n";
	 }else{
		 cout << "Alumno" << "\n\n";
	 }
	}

	void set_nombre(string usu){
		nombre_=usu;
	}
	void set_pass(string pass){
		contrasena_=pass;
	}
	void set_privilegio(string x){
		
		if (x == "profesor")
		{
			privilegio_=true;
		}
		else if (x =="alumno")
		{
			privilegio_=false;
		}
	}
};