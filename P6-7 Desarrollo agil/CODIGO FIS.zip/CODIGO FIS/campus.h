#pragma once

#include <set>
#include <fstream>
#include <cstdio>
#include <iostream>
#include <cstring>

using namespace std;

class Campus {

private:

	//set<Asignatura> asignaturas_;
	set<Usuario> alumnado_;

public:

	Campus() {
	}

	bool iniciar_sesion(string usu_, string pass_, Usuario &alu) {

		ifstream fich1;

		fich1.open("passwd.txt", ios::in);

		if (fich1.fail()) {
			cout << "No se pudo leer del fichero de datos\n";
		}
		else {

			bool encontrado_ = false;
			bool pass_corr_ = false;
			string usu;
			string pass;
			string privilegio;

			while (!fich1.eof() && ((pass_corr_ && encontrado_) != true)) {

				getline(fich1, usu, '\n');
				getline(fich1, pass, '\n');
				getline(fich1, privilegio, '\n');


				if (usu_ == usu) {

					if (pass_ == pass) {
						pass_corr_ = true;
					}
					else {
						pass_corr_ = false;
					}
					encontrado_ = true;
				}
				else {
					encontrado_ = false;
				}

			}

			if ((encontrado_ == true) && (pass_corr_ == true)) {
				cout << "Sesión iniciada con éxito" << endl;
				alu.set_nombre(usu);
				alu.set_pass(pass);
				alu.set_privilegio(privilegio);
				return true;
			}
			else if (encontrado_ == false)
			{
				cout << "Usuario no registrado en el sistema.\n";
				return false;
			}
			else if (pass_corr_ == false)
			{
				cout << "Contraseña incorrecta.\n";
				return false;
			}

			fich1.close();

		}

	}
};