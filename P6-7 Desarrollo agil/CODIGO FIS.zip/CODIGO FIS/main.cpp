#include <cstdio>
#include <iostream>
#include <cstring>

#include "usuarios.h"
#include "campus.h"

using namespace std;

int main()
{
    int opcion;
    Usuario usu;
    Campus campus;
    string user;
    string passwd;
 do{ 
    cout << "[0] Registrarse" << endl;
    cout << "[1] Iniciar sesión" << endl;
    cout << "[2] Recordar datos" << endl;
    cout << "[3] Salir" << endl;
    cin >> opcion;

  
       switch (opcion){
        case 0:
            usu.crear_usuario();
            break;

        case 1:

            cout << "Nombre de usuario: ";
            cin >> user;
            cout << "Contraseña: ";
            cin >> passwd;

            campus.iniciar_sesion(user, passwd, usu);

            break;

        case 2:
            usu.mostrar_datos();
            break;

        case 3:
            break;

    }

   }while(opcion!=3);

}
